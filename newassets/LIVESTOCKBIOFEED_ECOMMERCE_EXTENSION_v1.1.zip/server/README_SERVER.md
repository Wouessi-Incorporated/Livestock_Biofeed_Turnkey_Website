# Server notes
- Requires Node.js 18+ (native fetch)
- Run:
  - npm install
  - node server/server.js
- Configure .env
